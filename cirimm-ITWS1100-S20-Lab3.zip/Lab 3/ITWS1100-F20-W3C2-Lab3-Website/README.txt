link to website: https://afsws.rpi.edu/AFS/home/95/cirimm/public_html/iit/ITWS1100-F20-W3C2-Lab3-Website/index.html

Outline is located in the main directory and is titled "sitemap"

In this lab, I focused on creating a simple website layout that was centered on the page. I drew out what I wanted the site to look like before I began to
work on it, and that helped a lot. The key elements were a title bar, a vertical menu on the left, a content block on the ride, and a footbar at the bottom.
I used w3schools to help me with a fair bit of css, especially more advanced things such as the vertical menu hover color change feature. I used lorem ipsum
text to "proof" out how my content block would look if it is filled, and included an image to further spice up the page. I drew inspiration from the snowy
theme to create a snow-themed color palette, which I think looks nice. 