https://afsws.rpi.edu/AFS/home/95/cirimm/public_html/iit/ITWS1100-F20-W3C2-Lab3-Website/projects.html

This lab was about learning JQuery and manipulating webpages. Having used JQuery a fair bit, I knew what to do for most of the lab,
but learned that you can store element ids as vars, then concatenate them into functions.